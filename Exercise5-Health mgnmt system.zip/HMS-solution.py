import datetime
def gettime():
    return datetime.datetime.now()
def take(k):
    if k==1:
        c=int(input("enter 1 For Exercise and 2 For Food"))
        if(c == 1):
            value=input("type here\n")
            with open("kajal-ex.txt","a") as op:
                op.write(str([str(gettime())])+value+"\n")
            print("successfully written")
        else:
            value = input("type here\n")
            with open("kajal-food.txt", "a") as op:
                op.write(str([str(gettime())]) + value + "\n")
            print("successfully written")
    elif k==2:
        c = int(input("enter 1 For Exercise and 2 For Food"))
        if (c == 1):
            value = input("type here\n")
            with open("mona-ex.txt", "a") as op:
                op.write(str([str(gettime())]) + value + "\n")
            print("successfully written")
        else :
            value = input("type here\n")
            with open("mona-food.txt", "a") as op:
                op.write(str([str(gettime())]) + value + "\n")
            print("successfully written")
    elif k==3:
        c = int(input("enter 1 For Exercise and 2 For Food"))
        if (c == 1):
            value = input("type here\n")
            with open("vivek-ex.txt", "a") as op:
                op.write(str([str(gettime())]) + value + "\n")
            print("successfully written")
        else:
            value = input("type here\n")
            with open("vivek-food.txt", "a") as op:
                op.write(str([str(gettime())]) + value + "\n")
            print("successfully written")
    else:
        print("please enter valide inpt:1-kajal,2-mona,3-vivek")
def retrieve(k):
    if k==1:
        c=int(input("enter 1 for Exercise and 2 for Food"))
        if (c == 1):
            with open("kajal-ex.txt") as op:
                for i in op:
                    print(i,end="")
        elif(c == 2):
            with open("kajal-food.txt") as op:
                for i in op:
                    print(i,end="")
    elif k==2:
        c=int(input("enter 1 for Exercise and 2 for Food"))
        if (c == 1):
            with open("mona-ex.txt") as op:
                for i in op:
                    print(i,end="")
        elif(c == 2):
            with open("mona-food.txt") as op:
                for i in op:
                    print(i,end="")
    elif k==3:
        c=int(input("enter 1 for Exercise and 2 for Food"))
        if (c == 1):
            with open("vivek-ex.txt") as op:
                for i in op:
                    print(i,end="")
        elif(c == 2):
            with open("vivek-food.txt") as op:
                for i in op:
                    print(i,end="")
    else:
        print("please enter valid input(Kajal,Mona,vivek")
print("Health Management System")
a=int(input("Press 1 for Log value and 2 for Retrieve"))

if a==1:
    b=int(input("press 1 for kajal , 2 for mona and 3 for vivek"))
    take(b)
else:
    b=int(input("press 1 for kajal , 2 for mona and 3 for vivek"))
    retrieve(b)