# If __name__==__main__ usage & necessity
# Hum do python file create kar rahe hai tutmain1 and tutmain2
# first we will create two functions.

def printkajal(string):
    return f"ye string kajal ko de de thakure{string}"

def added(num1,num2):
    return num1+num2+5


print("aand the name is", __name__)

if __name__ == '__main__': #after using this , it shows output in main file not in file which is imported ie tutmain2.py
    print(printkajal("kajal"))
    o = added(4, 6)
    print(o)
# output:
# aand the name is __main__(it shows the main file tutmain.py)
# ye string kajal ko de de thakurekajal
# 15

# What are the Advantages of using if __name__ == “__main__” statement?

# Following are the advantages of using if __name__ == “__main__” statement:

# Using the main in our file, we can restrict some data from exporting to other files when imported.
# We can restrict the unnecessary data, thus making the output cleaner and more readable.
# We can choose what others may import or what they may not while using our module.


#  To summarise the concepts discussed in this tutorial, Modules in Python has a special attribute called __name__. The value of the __name__ attribute is set to __main__ when the module is run as the main program. Otherwise, the value of __name__ is set to the name of the module. The if __name__ == “__main__” block prevents the certain code from being run when the module is imported.