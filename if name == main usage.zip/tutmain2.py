import tutmain1
print("__name in tutmain.py is set to"+__name__)
print(tutmain1.added(5,6))

# we can access the function of tutmain1.py

# so __name__ =it shows main.py output only